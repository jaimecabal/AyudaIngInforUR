#include <iostream>

using namespace std;

int mostrarMenu();
int sumaDigitos(int num,int suma);
int normalizacion(int n,int norm);
int indiceNormalizacion(int n,int contador);

int main() {
	int n,suma=0,m,norm=0,contador=1;
	
	cout << "Introduce un numero para hacer pruebas." << endl;
	cin>>n;

	m=mostrarMenu();
	while(m!=0){
		switch(m){
			case 1:
				suma=sumaDigitos(n,suma);
				cout << "La suma total de los digitos de " << n << " es :" << suma << endl;
				break;
			case 2:
				suma=sumaDigitos(n,suma);
				cout << "La suma total de los digitos de " << n << " es :" << suma << endl;
				norm=normalizacion(suma,norm);
				cout << "La normalizacion de " << n << " es :" << norm << endl;
				break;
			case 3:
				contador=indiceNormalizacion(n,contador);
				cout << "El indice de normalizacion de " << n << " es :" << contador << endl;
				break;

			default:
				break;
		}
		m=mostrarMenu();
	}
}
int mostrarMenu(){
	int m;
	cout << "Los apartados del ejercicio son los siguientes:" << endl;
	cout << "0: Salir" << endl;
	cout << "1: Suma digitos" << endl;
	cout << "2: Normalizacion" << endl;
	cout << "3: Indice de normalizacion" << endl;
	cout << "4: Normalizacion e indice de normalizacion a la vez" <<endl;
	cin >> m;
	return m;
}
/*Apartado A*/
int sumaDigitos(int n,int s){
	/*Caso trivial: Si el numero que se introduce es menor que 10,
	la suma es el propio numero*/
	if(n<10){
		s=n+s;
		return s;
	}
	/*Caso general: cuando el numero es mayor que diez*/
	else{
		s=n%10+s;
		s=(sumaDigitos(n/10,s));
		return s;
	}
}
/*Apartado B*/
int normalizacion(int norm,int suma){
	/*Caso trivial: Cuando la normalizacion ya tiene un numero menor de 10*/
	if(norm<10){
		return norm;
	}
	/*Caso general: cuando el numero es mayor que diez*/
	/*Se va aplicando la funcion sumaDigitos*/
	else{
		norm=normalizacion(sumaDigitos(norm,suma),suma);
		return norm;
	}
}
/*Apartado C*/
int indiceNormalizacion(int n,int contador){
	cout << "n es :" << n << endl;
	if(n<10){
		return contador;
	}else{
		contador=indiceNormalizacion(n/10,contador+1);
		return contador;
	}
}