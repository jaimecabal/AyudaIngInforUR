#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string.h>

using namespace std;

void empleadosJornadaCompleta(char nombref[30]);
void consultaEmpleado(char dniEmpl[9]);

struct tEmpleado{
        char dni[9];
        char nombre[20];
        int horasTrabajadas;
        int precioHora;
};

int main(){
    char nombref[30];
    char dniEmpl[9];
    int n;

    cout << "Introduce el ejercicio que quieres enseñar" <<endl;
    cout << "1: Empleados que trabajen mas de 40 horas semanales" <<endl;
    cout << "2: Seleccion del empleado con DNI" <<endl;
    cin >> n;

    if(n==1){
        cout << "Introduce el nombre del fichero que contiene los empleados" << endl;
        cin >> nombref;

        empleadosJornadaCompleta(nombref);
    }else if(n==2){
        cout << "Introduce el empleado del que se quiere consultar" << endl;
        cin >> dniEmpl;

        consultaEmpleado(dniEmpl);
    }else{
        cout << "Inutil"<<endl;
    }
    return 0;
}

void empleadosJornadaCompleta(char nombref[30]){
    ifstream f;
    tEmpleado empl;

    f.open(nombref,ios::in);

    if(f){
        f>>empl.dni;
        cout << "--------------------------------" <<endl;
        while(!f.eof()){
            f>>empl.nombre;
            f>>empl.horasTrabajadas;
            f>>empl.precioHora;
            if(empl.horasTrabajadas>=40){
                cout << "Nombre: "<<empl.nombre <<endl;
                cout << "Sueldo: "<<empl.precioHora*empl.horasTrabajadas <<endl;
                cout << "--------------------------------" <<endl;
            }
            
            f>>empl.dni;
        }
    }else{
        cout << "Inutil"<<endl;
    }

    f.close();
}

void consultaEmpleado(char dniEmpl[9]){
    ifstream f;
    tEmpleado empl;
    bool encontrado;
    encontrado=false;
    f.open("empleados.dat",ios::in);
    if(f){
        f>>empl.dni;
        while(!f.eof() && encontrado==false){
            if(!strcmp(empl.dni,dniEmpl)){
                encontrado=true;
                f>>empl.nombre;
                break; /*Se deberia poder hacer sin break*/
            }
            f>>empl.nombre;
            f>>empl.horasTrabajadas;
            f>>empl.precioHora;
            f>>empl.dni;
        }
        if(encontrado==true){
            cout << "DNI: " << empl.dni << endl;
            /*Al salir por pantalla el DNI tambien
            saca el nombre a pesar del endl;*/
            cout << "Nombre: " << empl.nombre << endl;
        }else{
            cout << "Este empleado no existe" <<endl;
        }
    }else{
        cout << "Inutil" <<endl;
    }
    f.close();
}